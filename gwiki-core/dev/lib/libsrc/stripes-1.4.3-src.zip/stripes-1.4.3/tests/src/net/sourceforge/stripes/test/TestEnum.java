package net.sourceforge.stripes.test;

/**
 * A simple test Enum that can be used to test out enum handling in Stripes.
 *
 * @author Tim Fennell
 */
public enum TestEnum {
    First, Second, Third, Fourth, Fifth, Sixth, Seventh, Eight, Ninth, Tenth
}
